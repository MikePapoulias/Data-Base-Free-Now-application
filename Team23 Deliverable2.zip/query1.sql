SELECT Booking_code, Payment_amount, Payment_method, Card_number, Date
FROM payment
WHERE Number_of_id_card = 'AM391951';